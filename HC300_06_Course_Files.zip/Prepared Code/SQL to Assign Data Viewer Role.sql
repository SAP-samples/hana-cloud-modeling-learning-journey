-- EXERCISE: CREATE AND ASSIGN AN ANALYTIC PRIVILEGE

-- Preparation:
-- First replace @###### everywhere in this script with your assigned student number

-- 1. Assign DATA_VIEWER role to your user
GRANT "HC300_@######_HDI_DB_1"."HC::DATA_VIEWER" TO TRAIN_@######;

-- 2. Assign DATA_VIEWER2 role to your user and preview the calculation view
GRANT "HC300_@######_HDI_DB_1"."HC::DATA_VIEWER2" TO TRAIN_@######;
SELECT DISTINCT COUNTRY, CATEGORY FROM "HC300_@######_HDI_DB_1"."HC::CVCS_PO3_AP";

-- 3. Revoke role DATA_VIEWER2 and assign role DATA_VIEWER3 to your user, and preview the calculation view

REVOKE "HC300_@######_HDI_DB_1"."HC::DATA_VIEWER2" FROM TRAIN_@######;
GRANT "HC300_@######_HDI_DB_1"."HC::DATA_VIEWER3" TO TRAIN_@######;
SELECT DISTINCT COUNTRY, CATEGORY FROM "HC300_@######_HDI_DB_1"."HC::CVCS_PO3_AP";

-- 4. Revoke role DATA_VIEWER3 from your user (optional) 
REVOKE "HC300_@######_HDI_DB_1"."HC::DATA_VIEWER3" FROM TRAIN_@######;